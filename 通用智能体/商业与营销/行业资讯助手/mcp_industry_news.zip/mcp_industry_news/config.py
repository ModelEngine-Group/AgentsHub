import json
import os
from dataclasses import dataclass
from pathlib import Path

import yaml

from .models import Industry, Source

PACKAGE_DIR = Path(__file__).parent
CONFIG_DIR = PACKAGE_DIR / "industries"
DATA_DIR = PACKAGE_DIR / "data"
DB_PATH = DATA_DIR / "mcp_news.db"


@dataclass
class Settings:
    deepseek_api_key: str
    deepseek_base_url: str = "https://api.deepseek.com"
    proxy_url: str | None = None
    request_timeout: int = 15
    llm_batch_size: int = 60
    log_level: str = "INFO"


def load_settings() -> Settings:
    try:
        from dotenv import load_dotenv
        load_dotenv()
    except ImportError:
        pass

    key = os.environ.get("DEEPSEEK_API_KEY", "").strip()
    if not key:
        raise RuntimeError(
            "DEEPSEEK_API_KEY env var is required. "
            "Copy .env.example to .env and fill it in."
        )

    proxy = os.environ.get("HTTP_PROXY") or os.environ.get("HTTPS_PROXY")
    return Settings(
        deepseek_api_key=key,
        deepseek_base_url=os.environ.get("DEEPSEEK_BASE_URL", "https://api.deepseek.com"),
        proxy_url=proxy if proxy else None,
        log_level=os.environ.get("LOG_LEVEL", "INFO"),
    )


def load_industry_yaml(key: str) -> dict:
    path = CONFIG_DIR / f"{key}.yaml"
    if not path.exists():
        raise ValueError(f"Unknown industry: {key} (expected {path})")
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def sync_industries_to_db(SessionLocal) -> dict:
    """On startup, upsert YAML configs into industries/sources tables."""
    summary = {"industries": 0, "sources_added": 0}
    with SessionLocal() as s:
        for yml_path in CONFIG_DIR.glob("*.yaml"):
            cfg = yaml.safe_load(yml_path.read_text(encoding="utf-8"))
            if not cfg or "key" not in cfg:
                continue
            ind = s.query(Industry).filter_by(key=cfg["key"]).first()
            if not ind:
                ind = Industry(key=cfg["key"])
                s.add(ind)
            ind.display_name = cfg["display_name"]
            ind.system_prompt = cfg["system_prompt"]
            ind.priority_vendors = json.dumps(cfg.get("priority_vendors", []), ensure_ascii=False)
            ind.dedup_threshold = float(cfg.get("dedup_threshold", 0.65))
            ind.score_floor = int(cfg.get("score_floor", 40))
            s.flush()
            summary["industries"] += 1

            for src in cfg.get("sources", []):
                exists = s.query(Source).filter_by(industry_id=ind.id, url=src["url"]).first()
                if not exists:
                    s.add(Source(
                        industry_id=ind.id,
                        name=src["name"],
                        url=src["url"],
                        source_type=src.get("type", "国际"),
                    ))
                    summary["sources_added"] += 1
        s.commit()
    return summary
