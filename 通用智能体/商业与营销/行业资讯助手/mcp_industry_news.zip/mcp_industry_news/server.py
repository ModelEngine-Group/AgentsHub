import json
import logging
import os
from datetime import timedelta
from typing import Literal

from mcp.server.fastmcp import FastMCP

from .briefing import format_brief
from .config import load_settings, sync_industries_to_db, DB_PATH, DATA_DIR
from .analyst import analyse_industry
from .miner import scrape_industry, utc_now
from .models import Article, Industry, Insight, Source, init_db

# ---------------------------------------------------------------------------
# Bootstrap
# ---------------------------------------------------------------------------
DATA_DIR.mkdir(parents=True, exist_ok=True)
SETTINGS = load_settings()
logging.basicConfig(level=SETTINGS.log_level)
log = logging.getLogger("mcp-industry-news")

engine, SessionLocal = init_db(str(DB_PATH))
sync_summary = sync_industries_to_db(SessionLocal)
log.info("DB ready at %s — %s", DB_PATH, sync_summary)

mcp = FastMCP("industry-news")


# ---------------------------------------------------------------------------
# Helper — shared query logic
# ---------------------------------------------------------------------------
# Per-industry bonus keywords (applied to text-match for an extra score boost)
INDUSTRY_BONUS_KEYWORDS = {
    "digital_health": [
        "AI", "医疗AI", "影像AI", "医院", "三甲", "NMPA", "国家药监",
        "集采", "医保", "DRG", "DIP", "互联网医院", "联影", "迈瑞",
    ],
    "new_energy": [
        "销量", "交付", "上市", "固态电池", "钠离子", "4680",
        "智驾", "FSD", "城市NOA", "工信部", "补贴", "购置税",
    ],
    "semiconductor": [
        "EUV", "High-NA", "3nm", "2nm", "出口管制", "制裁",
        "国产化", "国产替代", "晶圆厂", "扩产", "良率", "流片",
    ],
    "cybersecurity": [
        "CVE", "0day", "零日", "勒索", "ransomware", "APT",
        "数据泄露", "等保", "关基", "国家级", "工信部", "供应链攻击",
    ],
    "fintech": [
        "央行", "数字人民币", "e-CNY", "牌照", "监管", "试点",
        "跨境支付", "反洗钱", "AML", "KYC", "征信", "互联互通",
    ],
    "ev_charging": [
        "国家电网", "南方电网", "超充", "800V", "兆瓦", "V2G",
        "虚拟电厂", "中标", "招标", "装机", "MWh", "GWh",
    ],
    "quantum": [
        "Nature", "Science", "PRL", "逻辑比特", "纠错", "容错",
        "量子优越性", "国家级", "墨子号", "QKD", "潘建伟",
    ],
    "robotics": [
        "量产", "工厂", "下线", "交付", "VLA", "端到端",
        "GR00T", "RT-2", "CVPR", "CoRL", "ICRA", "国产化",
    ],
}


def _query_top_news(industry: str, view: str, top_n: int):
    with SessionLocal() as s:
        ind = s.query(Industry).filter_by(key=industry).one_or_none()
        if not ind:
            return []
        vendors = json.loads(ind.priority_vendors) if ind.priority_vendors else []
        bonus_keywords = INDUSTRY_BONUS_KEYWORDS.get(industry, [])
        cutoff = utc_now() - timedelta(days=14)

        q = (
            s.query(Article, Insight, Source)
            .join(Insight, Insight.article_id == Article.id)
            .join(Source, Source.id == Article.source_id)
            .filter(
                Article.industry_id == ind.id,
                Article.published_at >= cutoff,
                Insight.impact_score >= ind.score_floor,
                Insight.category != "噪音",
            )
        )
        if view != "全局":
            q = q.filter(Insight.category == view)

        items = []
        for art, ins, src in q.all():
            text_lower = (art.title + " " + (ins.summary or "")).lower()
            text_raw = art.title + " " + (ins.summary or "")
            is_vendor = any(v.lower() in text_lower for v in vendors)
            is_local_source = (src.source_type == "国内")
            has_bonus_kw = any(kw in text_raw for kw in bonus_keywords)

            effective = ins.impact_score
            if is_vendor:
                effective += 15
            if is_local_source:
                effective += 8
            if has_bonus_kw:
                effective += 8

            items.append({
                "article_id": art.id,
                "title": art.title,
                "title_zh": ins.title_zh or art.title,
                "url": art.url,
                "summary": ins.summary or "",
                "score": ins.impact_score,
                "effective_score": effective,
                "category": ins.category,
                "source_name": src.name,
                "published_at": art.published_at.isoformat() if art.published_at else "",
                "is_vendor": is_vendor,
            })

        items.sort(key=lambda x: x["effective_score"], reverse=True)
        return items[:top_n]


# ---------------------------------------------------------------------------
# MCP Tools
# ---------------------------------------------------------------------------


@mcp.tool()
def fetch_top_news(
    industry: str,
    view: Literal["全局", "战略", "产品", "技术"] = "全局",
    top_n: int = 10,
    refresh: bool = False,
) -> dict:
    """
    Return Top-N cached news for an industry. Fast — reads from local DB only.

    To pull fresh articles from RSS sources and re-score them, call
    `refresh_industry(industry)` first (it may take 1-3 minutes), then call
    this tool. Setting refresh=True here is supported but discouraged for
    remote/HTTP transport: scraping + scoring can exceed proxy timeouts
    (e.g. Cloudflare's 100s edge limit) and the call may appear to hang.

    Args:
        industry: industry key — use list_industries() to see available ones (e.g. "storage")
        view: filter category — 全局 (all), 战略 (strategy), 产品 (product), 技术 (tech)
        top_n: how many items to return (default 10, max 50)
        refresh: if True, run miner + analyst inline before returning (slow, may time out)

    Returns:
        { "industry", "view", "items": [...], "stats": {...} }
    """
    top_n = min(top_n, 50)
    stats = {"new_articles": 0, "analysed": 0, "errors": []}

    if refresh:
        try:
            miner_result = scrape_industry(SessionLocal, SETTINGS, industry)
            stats["new_articles"] = miner_result.get("new_articles", 0)
        except ValueError as e:
            stats["errors"].append(str(e))
            return {"industry": industry, "view": view, "items": [], "stats": stats}

        try:
            stats["analysed"] = analyse_industry(SessionLocal, SETTINGS, industry)
        except Exception as e:
            log.warning("Analyse failed: %s", e)
            stats["errors"].append(f"analyse: {e}")

    return {
        "industry": industry,
        "view": view,
        "items": _query_top_news(industry, view, top_n),
        "stats": stats,
    }


@mcp.tool()
def refresh_industry(industry: str, analyse_limit: int = 12) -> dict:
    """
    Pull fresh articles from RSS sources for `industry` and score a small
    batch with the LLM. Designed to fit inside a single tool call without
    hitting reverse-proxy timeouts (Cloudflare ~100s).

    Call this BEFORE `fetch_top_news` when you want up-to-date data.
    Repeat the call to score more pending articles in subsequent batches.

    Args:
        industry: industry key (e.g. "digital_health")
        analyse_limit: max articles to score this round (default 12)

    Returns:
        { "industry", "new_articles", "analysed", "errors": [...] }
    """
    out = {"industry": industry, "new_articles": 0, "analysed": 0, "errors": []}
    try:
        miner_result = scrape_industry(SessionLocal, SETTINGS, industry)
        out["new_articles"] = miner_result.get("new_articles", 0)
    except ValueError as e:
        out["errors"].append(str(e))
        return out

    try:
        out["analysed"] = analyse_industry(
            SessionLocal, SETTINGS, industry, limit=analyse_limit
        )
    except Exception as e:
        log.warning("Analyse failed: %s", e)
        out["errors"].append(f"analyse: {e}")
    return out


@mcp.tool()
def search_news(
    industry: str,
    keyword: str = "",
    vendor: str = "",
    days: int = 14,
    limit: int = 20,
) -> dict:
    """
    Search cached articles by keyword and/or vendor over the last `days`.

    Args:
        industry: industry key (e.g. "storage")
        keyword: free-text search in title/content (optional)
        vendor: filter by vendor name in title (optional)
        days: look-back window (default 14)
        limit: max results (default 20, max 100)
    """
    limit = min(limit, 100)
    cutoff = utc_now() - timedelta(days=days)
    with SessionLocal() as s:
        ind = s.query(Industry).filter_by(key=industry).one_or_none()
        if not ind:
            return {"industry": industry, "items": []}
        q = (
            s.query(Article, Insight, Source)
            .outerjoin(Insight, Insight.article_id == Article.id)
            .join(Source, Source.id == Article.source_id)
            .filter(Article.industry_id == ind.id, Article.published_at >= cutoff)
        )
        if keyword:
            kw = f"%{keyword}%"
            q = q.filter(Article.title.ilike(kw) | Article.content.ilike(kw))
        if vendor:
            q = q.filter(Article.title.ilike(f"%{vendor}%"))
        q = q.order_by(Article.published_at.desc()).limit(limit)

        return {"industry": industry, "items": [
            {
                "article_id": a.id,
                "title": a.title,
                "title_zh": ins.title_zh if ins else None,
                "url": a.url,
                "score": ins.impact_score if ins else None,
                "category": ins.category if ins else None,
                "source_name": src.name,
                "published_at": a.published_at.isoformat() if a.published_at else "",
            }
            for a, ins, src in q.all()
        ]}


@mcp.tool()
def generate_daily_brief(industry: str, view: str = "全局", top_n: int = 10) -> str:
    """
    Generate a formatted Chinese daily-briefing text from cached data.

    Args:
        industry: industry key (e.g. "storage")
        view: 全局/战略/产品/技术
        top_n: items per brief (default 10)
    """
    items = _query_top_news(industry, view, top_n)
    with SessionLocal() as s:
        ind = s.query(Industry).filter_by(key=industry).one_or_none()
        display_name = ind.display_name if ind else industry
    return format_brief(display_name, items)


@mcp.tool()
def add_source(industry: str, name: str, url: str, source_type: str = "国际") -> dict:
    """
    Dynamically add an RSS source to an industry.

    Args:
        industry: industry key (e.g. "storage")
        name: display name for the source
        url: RSS/Atom feed URL
        source_type: 国内/国际/厂商 (default 国际)
    """
    with SessionLocal() as s:
        ind = s.query(Industry).filter_by(key=industry).one_or_none()
        if not ind:
            return {"ok": False, "reason": f"unknown industry: {industry}"}
        existing = s.query(Source).filter_by(industry_id=ind.id, url=url).first()
        if existing:
            return {"ok": True, "source_id": existing.id, "note": "already exists"}
        src = Source(industry_id=ind.id, name=name, url=url, source_type=source_type)
        s.add(src)
        s.commit()
        return {"ok": True, "source_id": src.id}


@mcp.tool()
def list_sources(industry: str) -> dict:
    """List all RSS sources configured for an industry."""
    with SessionLocal() as s:
        ind = s.query(Industry).filter_by(key=industry).one_or_none()
        if not ind:
            return {"industry": industry, "sources": []}
        return {"industry": industry, "sources": [
            {
                "id": x.id,
                "name": x.name,
                "url": x.url,
                "type": x.source_type,
                "enabled": bool(x.enabled),
                "last_fetched_at": x.last_fetched_at.isoformat() if x.last_fetched_at else None,
            }
            for x in s.query(Source).filter_by(industry_id=ind.id).all()
        ]}


@mcp.tool()
def list_industries() -> dict:
    """List all configured industries and their display names."""
    with SessionLocal() as s:
        return {"industries": [
            {"key": i.key, "display_name": i.display_name}
            for i in s.query(Industry).all()
        ]}


# ---------------------------------------------------------------------------
# Entrypoint
# ---------------------------------------------------------------------------

def main():
    transport = os.environ.get("MCP_TRANSPORT", "stdio")
    log.info("Starting MCP Industry News — transport=%s", transport)
    if transport in ("sse", "streamable-http", "http"):
        host = os.environ.get("MCP_HOST", "127.0.0.1")
        port = int(os.environ.get("MCP_PORT", "8000"))
        token = os.environ.get("MCP_AUTH_TOKEN", "").strip()
        mcp.settings.host = host
        mcp.settings.port = port

        # streamable-http is preferred for remote/proxy access (no long-lived
        # SSE connections that get buffered by Cloudflare/nginx). SSE still
        # works for local use but is not recommended behind reverse proxies.
        actual_transport = "streamable-http" if transport == "http" else transport
        log.info("HTTP binding %s:%d transport=%s (auth=%s)",
                 host, port, actual_transport, "on" if token else "OFF")

        if token:
            _run_http_with_auth(host, port, token, actual_transport)
        else:
            if host != "127.0.0.1":
                log.warning("Binding %s without MCP_AUTH_TOKEN — anyone on the network can call tools!", host)
            mcp.run(transport=actual_transport)
    else:
        mcp.run()


def _run_http_with_auth(host: str, port: int, token: str, transport: str):
    """Wrap FastMCP's app with a Bearer-token ASGI middleware and serve via uvicorn."""
    import uvicorn
    from starlette.responses import PlainTextResponse

    class BearerASGIMiddleware:
        """Raw ASGI middleware — does NOT buffer responses (safe for SSE/streamable-http)."""
        def __init__(self, app):
            self.app = app
            self.local_host = f"localhost:{port}".encode()
            self.local_server = ("localhost", port)

        async def __call__(self, scope, receive, send):
            if scope["type"] != "http":
                return await self.app(scope, receive, send)

            headers = dict(scope.get("headers", []))

            # 1) Auth check
            auth = headers.get(b"authorization", b"").decode("latin-1")
            if not auth.startswith("Bearer ") or auth[7:].strip() != token:
                await PlainTextResponse("unauthorized", status_code=401)(scope, receive, send)
                return

            # 2) Rewrite Host → localhost to prevent 421 behind reverse proxies
            headers[b"host"] = self.local_host
            scope = dict(scope)
            scope["headers"] = list(headers.items())
            scope["server"] = self.local_server

            await self.app(scope, receive, send)

    if transport == "sse":
        app = mcp.sse_app()
    else:
        app = mcp.streamable_http_app()

    wrapped = BearerASGIMiddleware(app)
    uvicorn.run(wrapped, host=host, port=port, log_level="info",
                forwarded_allow_ips="*", proxy_headers=True)


if __name__ == "__main__":
    main()