import hashlib
import re
import socket
import warnings
from typing import Iterable

import feedparser
import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
warnings.filterwarnings("ignore")

socket.setdefaulttimeout(15)

FAKE_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept": "application/rss+xml, application/xml, text/xml, */*;q=0.8",
}

_PUNCT_RE = re.compile(r"[\s\-_:|·\[\](){}'\"]+")


def normalize_title(title: str) -> str:
    return _PUNCT_RE.sub(" ", (title or "").lower()).strip()


def fingerprint(title: str) -> str:
    return hashlib.sha1(normalize_title(title).encode("utf-8")).hexdigest()[:16]


def is_similar_to_any(new_title: str, existing_titles: Iterable[str], threshold: float = 0.65) -> bool:
    from difflib import SequenceMatcher
    nl = normalize_title(new_title)
    for et in existing_titles:
        if SequenceMatcher(None, nl, normalize_title(et)).ratio() > threshold:
            return True
    return False


def fetch_feed_with_fallback(url: str, proxy_url: str | None = None, timeout: int = 10):
    """Try proxy first (if configured), then direct. Returns (feedparser_result, status_msg)."""
    attempts = []
    if proxy_url:
        attempts.append(("proxy", {"http": proxy_url, "https": proxy_url}))
    attempts.append(("direct", None))

    last_status = "no attempt"
    for label, proxies in attempts:
        try:
            r = requests.get(
                url, headers=FAKE_HEADERS, proxies=proxies,
                timeout=timeout, verify=False,
            )
            if r.status_code == 200:
                parsed = feedparser.parse(r.content)
                if parsed and getattr(parsed, "entries", None):
                    return parsed, f"{label} OK ({len(parsed.entries)} entries)"
                last_status = f"{label} OK but empty"
            else:
                last_status = f"{label} HTTP {r.status_code}"
        except Exception as e:
            last_status = f"{label} {type(e).__name__}: {e}"
    return None, last_status
