"""MCP Industry News — a configurable RSS scraper + AI scorer exposed via MCP."""
__version__ = "0.1.0"
