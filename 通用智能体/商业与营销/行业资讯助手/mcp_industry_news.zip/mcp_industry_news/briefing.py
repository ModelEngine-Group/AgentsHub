from datetime import datetime

_CATEGORY_EMOJI = {
    "战略": "🎯",
    "产品": "🚀",
    "技术": "💡",
    "资讯": "📡",
    "噪音": "🔇",
}


def format_brief(industry_display: str, items: list[dict]) -> str:
    """Format a list of scored news items into a Chinese daily-brief text."""
    day = datetime.now().strftime("%m月%d日")
    lines = [f"🔥【{industry_display}今日头条】{day}", ""]

    if not items:
        lines.append("暂无符合条件的热点新闻。")
        return "\n".join(lines)

    for i, p in enumerate(items, 1):
        emoji = "🏢" if p.get("is_vendor") else _CATEGORY_EMOJI.get(p.get("category", ""), "📡")
        source = p.get("source_name", "")
        title_zh = p.get("title_zh") or p.get("title", "")
        summary = p.get("summary", "") or ""
        url = p.get("url", "")

        lines.append(f"{i}.{emoji}[{source}] {title_zh}")
        if summary:
            lines.append(f"   {summary}")
        lines.append(f"   🔗 {url}")
        lines.append("")

    return "\n".join(lines).strip()