import json
import logging
import re
from datetime import timedelta

from .models import Industry, Article, Insight
from .miner import utc_now

log = logging.getLogger(__name__)


def _extract_json(text: str) -> str:
    """Pull the first {...} block out of a model reply that may include
    markdown fences or surrounding prose."""
    fence = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
    if fence:
        return fence.group(1)
    brace = re.search(r"\{.*\}", text, re.DOTALL)
    return brace.group(0) if brace else text


def analyse_industry(SessionLocal, settings, industry_key: str, limit: int = 60) -> int:
    """
    Find unscored articles (no Insight row) for the industry and
    call DeepSeek/OpenAI-compatible API to score them.
    Returns the number of articles successfully analysed.
    """
    from openai import OpenAI

    with SessionLocal() as s:
        ind = s.query(Industry).filter_by(key=industry_key).one()

        cutoff = utc_now() - timedelta(days=14)
        targets = (
            s.query(Article)
            .outerjoin(Insight)
            .filter(
                Article.industry_id == ind.id,
                Article.published_at >= cutoff,
                Insight.id.is_(None),
            )
            .limit(limit)
            .all()
        )
        if not targets:
            return 0

        client = OpenAI(
            api_key=settings.deepseek_api_key,
            base_url=settings.deepseek_base_url,
            timeout=60.0,
        )

        done = 0
        for art in targets:
            try:
                resp = client.chat.completions.create(
                    model="glm-5.1",
                    messages=[
                        {"role": "system", "content": ind.system_prompt},
                        {
                            "role": "user",
                            "content": (
                                f"Title: {art.title}\nContent: {art.content[:500]}\n\n"
                                "Respond with a single JSON object only — no prose, "
                                "no markdown fences."
                            ),
                        },
                    ],
                    temperature=0.1,
                    max_tokens=300,
                )
                raw = resp.choices[0].message.content.strip()
                try:
                    res = json.loads(_extract_json(raw))
                except json.JSONDecodeError:
                    log.warning(
                        "Article %s: model returned non-JSON, raw=%r",
                        art.id, raw[:400],
                    )
                    raise

                cat = res.get("category", "资讯")
                if isinstance(cat, list):
                    cat = cat[0] if cat else "资讯"
                summary = (res.get("summary") or "").replace("**", "").replace("__", "")

                s.add(Insight(
                    article_id=art.id,
                    title_zh=str(res.get("title_zh", art.title))[:200],
                    summary=summary[:300],
                    impact_score=int(res.get("score", 0) or 0),
                    category=str(cat),
                    raw_json=raw,
                ))
                s.commit()
                done += 1
            except Exception as e:
                log.warning("Analyse failed for article %s: %s", art.id, e)
                s.rollback()
    return done
