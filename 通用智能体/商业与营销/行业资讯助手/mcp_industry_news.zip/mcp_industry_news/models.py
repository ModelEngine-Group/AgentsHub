from datetime import datetime
from sqlalchemy import (
    Column, Integer, String, Text, Float, DateTime, ForeignKey,
    UniqueConstraint, Index, create_engine,
)
from sqlalchemy.orm import declarative_base, relationship, sessionmaker

Base = declarative_base()


class Industry(Base):
    __tablename__ = "industries"
    id = Column(Integer, primary_key=True)
    key = Column(String(64), unique=True, nullable=False)
    display_name = Column(String(128), nullable=False)
    system_prompt = Column(Text, nullable=False)
    priority_vendors = Column(Text, default="[]")
    dedup_threshold = Column(Float, default=0.65)
    score_floor = Column(Integer, default=40)
    created_at = Column(DateTime, default=datetime.utcnow)


class Source(Base):
    __tablename__ = "sources"
    id = Column(Integer, primary_key=True)
    industry_id = Column(Integer, ForeignKey("industries.id"), nullable=False, index=True)
    name = Column(String(128), nullable=False)
    url = Column(String(512), nullable=False)
    source_type = Column(String(32), default="国际")
    enabled = Column(Integer, default=1)
    last_fetched_at = Column(DateTime, nullable=True)
    __table_args__ = (UniqueConstraint("industry_id", "url", name="uq_source_industry_url"),)


class Article(Base):
    __tablename__ = "articles"
    id = Column(Integer, primary_key=True)
    industry_id = Column(Integer, ForeignKey("industries.id"), nullable=False, index=True)
    source_id = Column(Integer, ForeignKey("sources.id"), nullable=False)
    title = Column(Text, nullable=False)
    url = Column(String(1024), unique=True, nullable=False)
    content = Column(Text, default="")
    fingerprint = Column(String(64), index=True)
    published_at = Column(DateTime, index=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    insight = relationship("Insight", uselist=False, back_populates="article")
    __table_args__ = (Index("ix_industry_published", "industry_id", "published_at"),)


class Insight(Base):
    __tablename__ = "insights"
    id = Column(Integer, primary_key=True)
    article_id = Column(Integer, ForeignKey("articles.id"), unique=True, nullable=False)
    title_zh = Column(Text)
    summary = Column(Text)
    impact_score = Column(Integer, default=0, index=True)
    category = Column(String(32), index=True)
    raw_json = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    article = relationship("Article", back_populates="insight")


class ServedFingerprint(Base):
    __tablename__ = "served_fingerprints"
    id = Column(Integer, primary_key=True)
    industry_id = Column(Integer, ForeignKey("industries.id"), index=True)
    article_id = Column(Integer, ForeignKey("articles.id"), index=True)
    served_at = Column(DateTime, default=datetime.utcnow)


def init_db(db_path: str):
    engine = create_engine(f"sqlite:///{db_path}", future=True)
    Base.metadata.create_all(engine)
    SessionLocal = sessionmaker(bind=engine, expire_on_commit=False, future=True)
    return engine, SessionLocal
