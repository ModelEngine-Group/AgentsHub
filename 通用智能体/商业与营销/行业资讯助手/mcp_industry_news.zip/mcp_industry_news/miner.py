import logging
import time
from datetime import datetime, timedelta, timezone

from .models import Industry, Source, Article
from .utils import fetch_feed_with_fallback, is_similar_to_any, fingerprint

log = logging.getLogger(__name__)

_BANNED_SUBSTRINGS = {"优惠", "coupon", "deal", "sponsor", "直播"}
_MAX_ENTRIES_PER_FEED = 25


def utc_now():
    return datetime.now(timezone.utc).replace(tzinfo=None)


def scrape_industry(SessionLocal, settings, industry_key: str, lookback_days: int = 14) -> dict:
    """
    Scrape all enabled RSS sources for the given industry.
    Returns summary dict with per-source status and total new articles count.
    """
    results = {"industry": industry_key, "sources": [], "new_articles": 0}

    with SessionLocal() as s:
        ind = s.query(Industry).filter_by(key=industry_key).one_or_none()
        if not ind:
            raise ValueError(f"Industry '{industry_key}' not found in database")
        sources = s.query(Source).filter_by(industry_id=ind.id, enabled=1).all()
        if not sources:
            results["error"] = "no enabled sources"
            return results

        cutoff = utc_now() - timedelta(days=lookback_days)
        recent_titles = [
            t for (t,) in s.query(Article.title)
            .filter(Article.industry_id == ind.id, Article.created_at >= cutoff).all()
        ]

        for src in sources:
            feed, status = fetch_feed_with_fallback(src.url, settings.proxy_url)
            added = 0
            if not feed or not getattr(feed, "entries", None):
                src.last_fetched_at = utc_now()
                results["sources"].append({"name": src.name, "status": status, "added": 0})
                continue

            for entry in feed.entries[:_MAX_ENTRIES_PER_FEED]:
                title = getattr(entry, "title", "") or ""
                link = getattr(entry, "link", "") or ""
                if not title or not link:
                    continue
                if s.query(Article).filter_by(url=link).first():
                    continue
                if is_similar_to_any(title, recent_titles, ind.dedup_threshold):
                    continue
                if any(bad in title.lower() for bad in _BANNED_SUBSTRINGS):
                    continue

                pub = utc_now()
                if getattr(entry, "published_parsed", None):
                    try:
                        pub = datetime.fromtimestamp(time.mktime(entry.published_parsed))
                    except Exception:
                        pub = utc_now()
                if pub < cutoff:
                    continue

                s.add(Article(
                    industry_id=ind.id,
                    source_id=src.id,
                    title=title,
                    url=link,
                    content=(getattr(entry, "summary", "") or "")[:1000],
                    fingerprint=fingerprint(title),
                    published_at=pub,
                ))
                recent_titles.append(title)
                added += 1

            src.last_fetched_at = utc_now()
            s.flush()
            results["sources"].append({"name": src.name, "status": status, "added": added})
            results["new_articles"] += added

        s.commit()

    return results
