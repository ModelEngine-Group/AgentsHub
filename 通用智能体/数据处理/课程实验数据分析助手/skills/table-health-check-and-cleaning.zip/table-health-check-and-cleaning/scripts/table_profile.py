#!/usr/bin/env python3
"""表格体检骨架：输出工作表、表头、字段类型、缺失/重复/前导零/日期格式/异常值概况。
只读，不修改源文件。用法：
    python table_profile.py <path/to/file.xlsx|.csv> [--sheet SHEET]
"""
import argparse
import re
import sys

import pandas as pd

MISSING_PLACEHOLDERS = {"", "null", "n/a", "na", "-", "--", "无", "未知"}
ID_KEYWORDS = ("编号", "代码", "编码", "id", "工号", "邮编", "电话")
DATE_RE = re.compile(r"^\d{4}[-/]\d{1,2}[-/]\d{1,2}$")


def load(path, sheet=None):
    if path.lower().endswith(".csv"):
        return {"CSV": pd.read_csv(path, dtype=str)}
    return pd.read_excel(path, sheet_name=sheet, dtype=str)


def is_missing(series):
    s = series.fillna("").astype(str).str.strip()
    return s.str.lower().isin(MISSING_PLACEHOLDERS)


def profile_sheet(df):
    report = {"rows": len(df), "cols": len(df.columns), "issues": []}
    for col in df.columns:
        s = df[col].fillna("").astype(str).str.strip()

        n_missing = int(is_missing(df[col]).sum())
        if n_missing:
            report["issues"].append((col, "缺失值", n_missing, "空/占位符"))

        lower = str(col).lower()
        if any(k in lower for k in ID_KEYWORDS):
            short = s[(s.str.fullmatch(r"\d+")) & (s.str.len() < s.str.len().max())]
            if len(short):
                report["issues"].append((col, "疑似前导零丢失", len(short), short.iloc[0]))

        if s.str.contains(DATE_RE, na=False).any():
            variants = s[s.str.contains(r"\d", na=False)].str.replace(r"\d", "D", regex=True)
            n_fmt = variants[variants.str.fullmatch(r"D+[-/]D+[-/]D+")].nunique()
            if n_fmt > 1:
                bad = int(~s.str.fullmatch(r"\d{4}-\d{2}-\d{2}") & s.ne(""))
                report["issues"].append((col, "日期格式不统一", bad, f"{n_fmt} 种格式"))

    dup = int(df.duplicated().sum())
    if dup:
        report["issues"].append(("全部列", "完全重复", dup, "整行相同"))
    return report


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("path")
    ap.add_argument("--sheet", default=None)
    args = ap.parse_args()

    try:
        sheets = load(args.path, args.sheet)
    except Exception as exc:  # noqa: BLE001
        sys.exit(f"读取失败: {exc}")

    for name, df in sheets.items():
        print(f"\n=== 工作表: {name} ===")
        print(f"行数: {len(df)} | 列数: {len(df.columns)}")
        print("列名:", ", ".join(map(str, df.columns)))
        r = profile_sheet(df)
        if not r["issues"]:
            print("未发现问题。")
            continue
        print(f"{'问题类型':<14}{'涉及列':<16}{'受影响行数':<10}示例")
        for col, kind, n, sample in r["issues"]:
            print(f"{kind:<14}{str(col):<16}{n:<10}{sample}")


if __name__ == "__main__":
    main()
