#!/usr/bin/env python3
"""分组对比可视化脚本：生成排序条形图/分组条形图/小多图/正负贡献条形图，并输出数值表与贡献合计核对。"""

import argparse
import json
from typing import Dict, List, Tuple

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

TOLERANCE = 1e-6


def load_data(path: str) -> Dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def plot_sorted_bar(groups: List[str], values: List[float], title: str, out: str) -> None:
    pairs = sorted(zip(groups, values), key=lambda x: x[1], reverse=True)
    names = [p[0] for p in pairs]
    vals = [p[1] for p in pairs]
    plt.figure(figsize=(8, max(3, 0.5 * len(names))))
    bars = plt.barh(names[::-1], vals[::-1], color="#2b7bba")
    for bar, v in zip(bars, vals[::-1]):
        plt.text(bar.get_width(), bar.get_y() + bar.get_height() / 2, f"{v:,.2f}", va="center")
    plt.title(title)
    plt.tight_layout()
    plt.savefig(out, dpi=150)
    plt.close()
    print("排序条形图数值表：")
    for i, (n, v) in enumerate(pairs, 1):
        print(f"  排名{i}  {n}: {v:,.2f}")


def plot_grouped_bar(groups: List[str], series: Dict[str, List[float]], title: str, out: str) -> None:
    import numpy as np

    idx = np.arange(len(groups))
    n = len(series)
    width = 0.8 / max(n, 1)
    plt.figure(figsize=(9, 4.5))
    for i, (name, vals) in enumerate(series.items()):
        plt.bar(idx + i * width - 0.4 + width / 2, vals, width, label=name)
    plt.xticks(idx, groups)
    plt.legend()
    plt.title(title)
    plt.tight_layout()
    plt.savefig(out, dpi=150)
    plt.close()
    print("分组条形图数值表：")
    print("  组别\t" + "\t".join(series.keys()))
    for gi, g in enumerate(groups):
        row = [f"{series[k][gi]:,.2f}" for k in series]
        print(f"  {g}\t" + "\t".join(row))


def plot_small_multiples(panels: Dict[str, Tuple[List[str], List[float]]], title: str, out: str) -> None:
    names = list(panels.keys())
    fig, axes = plt.subplots(1, len(names), figsize=(4 * len(names), 3), sharey=True)
    if len(names) == 1:
        axes = [axes]
    for ax, name in zip(axes, names):
        xs, ys = panels[name]
        ax.plot(xs, ys, marker="o")
        ax.set_title(name)
    fig.suptitle(title)
    plt.tight_layout()
    plt.savefig(out, dpi=150)
    plt.close()
    print("小多图数值表：")
    for name, (xs, ys) in panels.items():
        print(f"  [{name}] " + ", ".join(f"{x}:{y:,.2f}" for x, y in zip(xs, ys)))


def plot_contribution(groups: List[str], before: List[float], after: List[float], title: str, out: str) -> None:
    contribs = [a - b for a, b in zip(after, before)]
    total_change = sum(after) - sum(before)
    total_contrib = sum(contribs)
    order = sorted(range(len(groups)), key=lambda i: abs(contribs[i]), reverse=True)
    names = [groups[i] for i in order]
    vals = [contribs[i] for i in order]
    colors = ["#c0392b" if v < 0 else "#27ae60" for v in vals]
    plt.figure(figsize=(8, max(3, 0.5 * len(names))))
    plt.barh(names[::-1], vals[::-1], color=colors[::-1])
    plt.axvline(0, color="black", linewidth=0.8)
    plt.title(title)
    plt.tight_layout()
    plt.savefig(out, dpi=150)
    plt.close()
    print("贡献条形图数值表：")
    for i in order:
        print(f"  {groups[i]}\t上期 {before[i]:,.2f}\t本期 {after[i]:,.2f}\t贡献 {contribs[i]:+,.2f}")
    print(f"  贡献合计: {total_contrib:+,.2f}")
    print(f"  总量变化: {total_change:+,.2f}")
    ok = abs(total_contrib - total_change) <= TOLERANCE
    print(f"  核对结果: {'一致' if ok else '不一致，请核查数据'} (差值 {total_contrib - total_change:+.6f})")


def main() -> None:
    parser = argparse.ArgumentParser(description="分组对比可视化")
    parser.add_argument("--data", required=True, help="JSON 数据文件路径")
    parser.add_argument("--out", required=True, help="输出图片路径")
    parser.add_argument("--chart", choices=["sorted_bar", "grouped_bar", "small_multiples", "contribution"], required=True)
    parser.add_argument("--title", default="分组对比")
    args = parser.parse_args()

    data = load_data(args.data)
    if args.chart == "sorted_bar":
        plot_sorted_bar(data["groups"], data["values"], args.title, args.out)
    elif args.chart == "grouped_bar":
        plot_grouped_bar(data["groups"], data["series"], args.title, args.out)
    elif args.chart == "small_multiples":
        panels = {k: (v["x"], v["y"]) for k, v in data["panels"].items()}
        plot_small_multiples(panels, args.title, args.out)
    elif args.chart == "contribution":
        plot_contribution(data["groups"], data["before"], data["after"], args.title, args.out)


if __name__ == "__main__":
    main()
