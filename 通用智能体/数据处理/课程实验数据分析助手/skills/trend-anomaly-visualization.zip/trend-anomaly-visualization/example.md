# 使用示例

## 示例 1：日活用户下跌分析

**请求**：分析过去 30 天 DAU 走势，标出异常并叠加周同比。

**对齐口径**：
- 粒度：日（按天求和去重后的活跃用户数）
- 时区：数据为 UTC，展示换算为北京时间 UTC+8
- 窗口：当前 30 天，对照为上周同星期序列
- 指标：DAU，单位为万人，去重计数

**绘制**：折线图 + 上周同日虚线对比；缺失 3 天（5/06–5/08）保留断点；最后一天标为未结束周期（数据截至当日 06:00）。

**叠加层**：上周同日对比线；MA7 平滑线。

**异常标注**：
- 异常开始：5/12
- 峰值（最大跌幅）：5/15，DAU 从基线 120 万降至 88 万
- 恢复时间：5/19 回到基线 ±3% 区间内

**图下说明**：
- 异常幅度：峰值下跌 32 万（-26.7%），累计受影响 8 天
- 受影响范围：全端 DAU；其中 App 端下降 24 万，占主要部分；Web 端基本持平
- 仍需验证的原因：
  1. 5/13 App 版本发布导致崩溃率上升——验证方式：核对发布记录与崩溃率指标
  2. 5/12–5/15 支付渠道故障影响活跃度——验证方式：交叉核对支付成功率
  3. 季节性波动——验证方式：对照去年同期同星期数据

---

## 示例 2：接口错误率告警与恢复

**请求**：展示某接口 24 小时错误率，叠加 SLA 阈值，标注异常区间。

**对齐口径**：
- 粒度：分钟聚合，展示时合并为 5 分钟桶
- 时区：北京时间
- 窗口：24 小时，无同期对照（仅阈值参考）
- 指标：错误率 = 5xx 请求数 / 总请求数，单位 %

**绘制**：折线图 + 5% SLA 阈值水平线，超过阈值的区间以红色阴影标注。

**异常标注**：
- 异常开始：09:42
- 峰值：09:58，错误率 18.4%
- 恢复时间：10:35 回落至阈值以下

**图下说明**：
- 异常幅度：峰值超阈值 13.4 个百分点，累计超阈值时长 53 分钟
- 受影响范围：请求量约 42 万次，涉及三个下游依赖中的两个
- 仍需验证的原因：
  1. 数据库连接池耗尽——验证方式：核对当时连接数监控
  2. 上游流量突增——验证方式：对照 QPS 曲线
  3. 依赖服务超时连锁——验证方式：查看依赖方超时日志

---

## 绘图代码参考（matplotlib）

```python
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

def plot_trend(df, ts_col, val_col, title,
               missing_gaps=None, open_period_end=None,
               compare_series=None, threshold=None, ma_window=None,
               anomalies=None, ylabel="指标值", tz=None):
    """
    df: 含时间与指标值的 DataFrame
    missing_gaps: [(start, end), ...] 缺失区间，保留断点
    open_period_end: 未结束周期起点（该段以虚线绘制）
    compare_series: (label, Series) 对照层
    threshold: (label, value) 业务阈值
    ma_window: 移动平均窗口（按行数）
    anomalies: [{"label":..., "start":..., "peak":..., "end":...}]
    """
    d = df.copy()
    d[ts_col] = pd.to_datetime(d[ts_col])
    d = d.sort_values(ts_col).set_index(ts_col)[val_col]

    # 显式制造断点
    if missing_gaps:
        for s, e in missing_gaps:
            idx = pd.date_range(s, e, freq=pd.infer_freq(d.index) or "D")
            d = d.drop(index=[i for i in idx if i in d.index], errors="ignore")
        d = d.reindex(pd.date_range(d.index.min(), d.index.max(),
                                    freq=pd.infer_freq(d.index) or "D"))

    fig, ax = plt.subplots(figsize=(12, 5))
    ax.plot(d.index, d.values, label="当前", color="#1f77b4", linewidth=1.8)

    if ma_window:
        ax.plot(d.index, d.rolling(ma_window, min_periods=1).mean(),
                label=f"MA{ma_window}", color="#ff7f0e", linestyle="--", linewidth=1.2)

    if compare_series:
        lbl, s = compare_series
        ax.plot(s.index, s.values, label=lbl, color="#7f7f7f",
                linestyle=":", linewidth=1.2)

    if threshold:
        lbl, v = threshold
        ax.axhline(v, color="#d62728", linestyle="-.", linewidth=1.2, label=lbl)

    if open_period_end is not None:
        oe = pd.to_datetime(open_period_end)
        tail = d[d.index >= oe]
        ax.plot(tail.index, tail.values, color="#1f77b4", linewidth=1.8,
                linestyle="--", alpha=0.7)
        ax.axvspan(oe, d.index.max(), color="#cccccc", alpha=0.25)
        ax.annotate("未结束周期", xy=(oe, d.max()), xytext=(oe, d.max()),
                    fontsize=9, color="#555")

    if anomalies:
        colors = ["#9467bd", "#8c564b", "#e377c2", "#17becf"]
        for i, a in enumerate(anomalies):
            c = colors[i % len(colors)]
            ax.axvspan(pd.to_datetime(a["start"]), pd.to_datetime(a["end"]),
                       color=c, alpha=0.12)
            for k in ("start", "peak", "end"):
                if k in a and pd.notna(a[k]):
                    ax.axvline(pd.to_datetime(a[k]), color=c,
                               linestyle="--", linewidth=1)
                    ax.annotate(a.get("label", f"异常{i+1}") + "-" + k,
                                xy=(pd.to_datetime(a[k]), d.max()),
                                rotation=90, fontsize=8, color=c)

    if tz:
        ax.set_xlabel(f"时间（{tz}）")
    else:
        ax.set_xlabel("时间")
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.legend(loc="best")
    fig.autofmt_xdate()
    fig.tight_layout()
    return fig
```
