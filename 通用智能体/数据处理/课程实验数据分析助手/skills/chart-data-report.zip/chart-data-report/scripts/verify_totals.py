#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""核对分项合计与百分比分母：输入 JSON，输出差异清单。

输入 JSON 结构：
{
  "items": {"自然流量": 19450, "投放": 15200, "合作": 7400},
  "claimed_total": 42000,
  "claims": [{"label": "自然流量占比", "value": 46.3, "numerator": 19446, "denominator": 42000}]
}

输出：分项和、与声称合计的差、每条占比声明按分子和按分母重算的结果与误差。
"""

import json
import sys


def check(data):
    items = data.get("items", {})
    total = sum(items.values())
    results = {"items_sum": total, "claimed_total": data.get("claimed_total")}

    if data.get("claimed_total") is not None:
        results["total_diff"] = round(total - data["claimed_total"], 4)
        results["total_consistent"] = abs(results["total_diff"]) < 0.5

    claims = []
    for c in data.get("claims", []):
        den = c.get("denominator")
        num = c.get("numerator")
        entry = {"label": c.get("label"), "claimed_pct": c.get("value")}
        if den:
            entry["pct_from_numerator"] = round(num / den * 100, 2) if num is not None else None
            entry["pct_from_items_sum"] = round(items.get(c.get("label"), 0) / total * 100, 2) if total else None
            entry["pct_error"] = (
                round(entry["pct_from_numerator"] - c.get("value"), 2)
                if entry["pct_from_numerator"] is not None and c.get("value") is not None
                else None
            )
        claims.append(entry)
    results["claims"] = claims

    issues = []
    if results.get("total_consistent") is False:
        issues.append(f"分项合计 {total} 与声称合计 {data['claimed_total']} 相差 {results['total_diff']}")
    for c in claims:
        if c.get("pct_error") is not None and abs(c["pct_error"]) > 0.05:
            issues.append(f"{c['label']}：声明 {c['claimed_pct']}%，按分子/分母重算 {c['pct_from_numerator']}%")
    results["issues"] = issues
    return results


if __name__ == "__main__":
    payload = json.load(sys.stdin) if not sys.argv[1:] else json.load(open(sys.argv[1], encoding="utf-8"))
    print(json.dumps(check(payload), ensure_ascii=False, indent=2))
