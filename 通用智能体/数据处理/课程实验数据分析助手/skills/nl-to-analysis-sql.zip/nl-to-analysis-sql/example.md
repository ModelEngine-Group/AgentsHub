# 使用示例

## 示例 1：按天统计下单用户数（去重口径）

**用户问题**：统计 2026-01-01 至 2026-01-31 每天有多少个用户下单。

**已知结构**：`orders(order_id, user_id, amount, created_at)`，MySQL。

**口径确认**：粒度为「天」；日期字段为 `created_at`（下单时间）；指标为下单用户数，需 `COUNT(DISTINCT user_id)`。

```sql
WITH base AS (
  SELECT user_id, DATE(created_at) AS dt
  FROM orders
  WHERE created_at >= :start_date
    AND created_at <  :end_date_exclusive
)
SELECT dt,
       COUNT(DISTINCT user_id) AS order_users
FROM base
GROUP BY dt
ORDER BY dt;
```

**JOIN 检查**：单表，无重复计数风险。
**结果字段**：`dt`（日期）、`order_users`（当日去重下单用户数）。

---

## 示例 2：多表关联的重复计数规避

**用户问题**：统计每个品类 1 月销售额与下单笔数。

**已知结构**：`orders(order_id, amount, created_at)`、`order_item(order_id, product_id, qty)`、`product(product_id, category)`，PostgreSQL。

**风险**：`orders` 与 `order_item` 为一对多，直接 JOIN 后 `SUM(amount)` 会被放大。

```sql
WITH paid_orders AS (
  SELECT order_id, amount
  FROM orders
  WHERE created_at >= :start_date
    AND created_at <  :end_date_exclusive
),
item_agg AS (          -- 先按订单汇总明细，避免放大
  SELECT order_id, product_id, SUM(qty) AS qty
  FROM order_item
  GROUP BY order_id, product_id
),
order_category AS (    -- 一笔订单可能跨品类，按品类拆分
  SELECT i.order_id,
         p.category,
         MIN(o.amount) AS amount   -- 订单金额只取一次，避免重复累加
  FROM item_agg i
  JOIN paid_orders o ON o.order_id = i.order_id
  JOIN product p     ON p.product_id = i.product_id
  GROUP BY i.order_id, p.category
)
SELECT category,
       COUNT(DISTINCT order_id) AS order_cnt,
       SUM(amount)              AS gmv
FROM order_category
GROUP BY category
ORDER BY gmv DESC;
```

**口径说明**：`order_cnt` 为去重订单数；`gmv` 按「订单-品类」拆分后累加，跨品类订单会在多个品类中各计一次金额，若需不重复的 GMV 需改用订单主品类归属规则（需要业务确认）。
**结果字段**：`category`（品类）、`order_cnt`（订单数）、`gmv`（销售额）。

---

## 示例 3：时间趋势与补齐缺失日期

**用户问题**：按月看 2026 年各月新增用户数。

```sql
-- PostgreSQL
WITH months AS (
  SELECT generate_series(DATE '2026-01-01', DATE '2026-12-01', INTERVAL '1 month')::date AS mon
),
new_users AS (
  SELECT DATE_TRUNC('month', created_at)::date AS mon,
         COUNT(DISTINCT user_id) AS new_users
  FROM users
  WHERE created_at >= DATE '2026-01-01'
    AND created_at <  DATE '2027-01-01'
  GROUP BY 1
)
SELECT m.mon, COALESCE(n.new_users, 0) AS new_users
FROM months m
LEFT JOIN new_users n USING (mon)
ORDER BY m.mon;
```

MySQL 无 `generate_series`，可改用递归 CTE 或用日历表关联。

---

## 示例 4：需要先追问的情形

**用户问题**：看看最近订单情况。

**追问内容**：
1. 「最近」指最近 7 天、30 天还是本月？
2. 需要哪些指标：订单量、GMV、下单用户数、客单价？
3. 是否按天/按渠道/按品类拆分？
4. `orders` 表中金额字段是否含退款或测试单，是否需要过滤？

无法确认时不要猜测口径，先补齐再生成。
