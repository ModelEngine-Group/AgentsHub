"""通用绘图辅助函数：统一单位、标注缺失与未完成周期、输出 PNG/SVG/HTML。

依赖：pandas, matplotlib（可选 plotly）
"""

from __future__ import annotations

import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl

# 中文显示
mpl.rcParams["font.sans-serif"] = ["SimHei", "Microsoft YaHei", "Noto Sans CJK SC", "Arial Unicode MS"]
mpl.rcParams["axes.unicode_minus"] = False


def plot_trend(df: pd.DataFrame, x: str, y: str, xlabel: str, ylabel: str,
               title: str, incomplete_note: str | None = None,
               out: str = "trend.png", fmt: str = "png") -> str:
    """时间趋势折线图。缺失值保留断点（不插值）。

    incomplete_note: 若最后一段周期未完成，传入说明，例如 "12 月截至 20 日"，该段用虚线。
    """
    fig, ax = plt.subplots(figsize=(9, 4.5))
    values = pd.to_numeric(df[y], errors="coerce")
    ax.plot(df[x], values, marker="o", linewidth=1.8, color="#2b6cb0", label=None)

    if incomplete_note and len(df) >= 2:
        # 最后一段用虚线标注未完成周期
        ax.plot(df[x].iloc[-2:], values.iloc[-2:], linestyle="--", color="#2b6cb0")
        ax.annotate(incomplete_note, xy=(df[x].iloc[-1], values.iloc[-1]),
                    xytext=(0, 12), textcoords="offset points", ha="right", fontsize=8, color="#666666")

    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.grid(axis="y", linestyle=":", alpha=0.4)
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(out, format=fmt, dpi=150)
    plt.close(fig)
    return out


def plot_category_bar(df: pd.DataFrame, category: str, value: str,
                      xlabel: str, ylabel: str, title: str,
                      ascending: bool = False, out: str = "bar.png", fmt: str = "png") -> str:
    """类别比较横向条形图，按数值排序并在末端标注数值。"""
    d = df[[category, value]].copy()
    d[value] = pd.to_numeric(d[value], errors="coerce")
    d = d.dropna(subset=[value]).sort_values(value, ascending=ascending)

    fig, ax = plt.subplots(figsize=(8, max(3, 0.5 * len(d) + 1)))
    bars = ax.barh(d[category].astype(str), d[value], color="#4299e1")
    for bar, v in zip(bars, d[value]):
        ax.text(v, bar.get_y() + bar.get_height() / 2, f" {v:,.0f}",
                va="center", fontsize=8)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.grid(axis="x", linestyle=":", alpha=0.4)
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(out, format=fmt, dpi=150)
    plt.close(fig)
    return out


def plot_distribution_box(df: pd.DataFrame, group: str, value: str,
                          xlabel: str, ylabel: str, title: str,
                          out: str = "box.png", fmt: str = "png") -> str:
    """分组箱线图，显示中位数、四分位与异常点。自动剔除负值与 0。"""
    d = df[[group, value]].copy()
    d[value] = pd.to_numeric(d[value], errors="coerce")
    dropped = int((d[value] <= 0).sum() + d[value].isna().sum())
    d = d[d[value] > 0].dropna()

    groups = [g[value].values for _, g in d.groupby(group)]
    labels = [str(k) for k, _ in d.groupby(group)]
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.boxplot(groups, labels=labels, showfliers=True)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(f"{title}（剔除无效值 {dropped} 条）" if dropped else title)
    ax.grid(axis="y", linestyle=":", alpha=0.4)
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(out, format=fmt, dpi=150)
    plt.close(fig)
    return out


def plot_scatter(df: pd.DataFrame, x: str, y: str, xlabel: str, ylabel: str,
                 title: str, trendline: bool = True,
                 out: str = "scatter.png", fmt: str = "png") -> str:
    """散点图，可选线性趋势线，标题注明样本量。"""
    d = df[[x, y]].apply(pd.to_numeric, errors="coerce").dropna()
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.scatter(d[x], d[y], s=18, alpha=0.6, color="#2b6cb0")
    if trendline and len(d) >= 2:
        import numpy as np
        k, b = np.polyfit(d[x], d[y], 1)
        xs = np.linspace(d[x].min(), d[x].max(), 100)
        ax.plot(xs, k * xs + b, color="#e53e3e", linewidth=1.5, linestyle="--")
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(f"{title}（n={len(d)}）")
    ax.grid(linestyle=":", alpha=0.4)
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(out, format=fmt, dpi=150)
    plt.close(fig)
    return out


def to_interactive_html(df: pd.DataFrame, x: str, y: str, title: str,
                        xlabel: str, ylabel: str, out: str = "chart.html") -> str:
    """生成可交互 HTML（悬浮提示）。无 plotly 时抛出 ImportError。"""
    import plotly.express as px
    fig = px.line(df, x=x, y=y, title=title, labels={x: xlabel, y: ylabel})
    fig.write_html(out, include_plotlyjs="cdn")
    return out
