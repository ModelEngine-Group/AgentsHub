#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""review_diff.py - deterministic helpers for code review on unified diffs.

Modes
-----
parse   unified diff -> JSON with per-file hunks and RIGHT-side line numbers
scan    added lines -> candidate findings (secrets, dangerous calls, debris)
verify  findings JSON -> check every (file, line) anchors to a real line

Only the Python standard library is used. No network access. Secret values are
masked before they are written to stdout.

Examples
--------
python review_diff.py --mode parse  --diff reviews/pr.diff --out reviews/parsed.json
python review_diff.py --mode scan   --diff reviews/pr.diff --out reviews/scan.json
python review_diff.py --mode verify --diff reviews/pr.diff --findings reviews/findings.json
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Iterable

SEVERITY_ORDER = {"P0": 0, "P1": 1, "P2": 2, "P3": 3}

EXT_LANG = {
    ".py": "python",
    ".pyi": "python",
    ".js": "javascript",
    ".jsx": "javascript",
    ".mjs": "javascript",
    ".cjs": "javascript",
    ".ts": "typescript",
    ".tsx": "typescript",
    ".java": "java",
    ".go": "go",
    ".rb": "ruby",
    ".php": "php",
    ".cs": "csharp",
    ".rs": "rust",
    ".kt": "kotlin",
    ".scala": "scala",
    ".sql": "sql",
    ".sh": "shell",
    ".bash": "shell",
    ".ps1": "powershell",
    ".yml": "yaml",
    ".yaml": "yaml",
    ".json": "json",
    ".toml": "toml",
    ".md": "markdown",
    ".html": "html",
    ".css": "css",
}

SOURCE_EXTS = {".py", ".js", ".jsx", ".ts", ".tsx", ".java", ".go", ".rb", ".php", ".cs", ".rs", ".kt"}

DEPENDENCY_FILES = {
    "requirements.txt",
    "requirements-dev.txt",
    "pyproject.toml",
    "poetry.lock",
    "pipfile",
    "pipfile.lock",
    "setup.py",
    "setup.cfg",
    "package.json",
    "package-lock.json",
    "yarn.lock",
    "pnpm-lock.yaml",
    "go.mod",
    "go.sum",
    "pom.xml",
    "build.gradle",
    "build.gradle.kts",
    "cargo.toml",
    "cargo.lock",
}

SENSITIVE_NAMES = {
    "dockerfile",
    "docker-compose.yml",
    "docker-compose.yaml",
    ".env",
    ".env.example",
    "settings.py",
    "config.py",
    "nginx.conf",
    "application.yml",
    "application.properties",
}


# --------------------------------------------------------------------------
# diff parsing
# --------------------------------------------------------------------------

def _clean_path(raw: str) -> str:
    p = raw.strip()
    if len(p) >= 2 and p[0] == '"' and p[-1] == '"':
        p = p[1:-1].replace('\\"', '"').replace("\\\\", "\\")
    if "\t" in p:
        p = p.split("\t", 1)[0]
    return p.strip()


def _strip_prefix(p: str) -> str:
    if p in ("", "/dev/null"):
        return p
    if p.startswith(("a/", "b/")):
        return p[2:]
    return p


def _new_file() -> dict[str, Any]:
    return {
        "path": None,
        "old_path": None,
        "language": "text",
        "is_new": False,
        "is_deleted": False,
        "binary": False,
        "added": 0,
        "deleted": 0,
        "hunks": [],
    }


def parse_diff(text: str) -> dict[str, Any]:
    files: list[dict[str, Any]] = []
    cur: dict[str, Any] | None = None
    hunk: dict[str, Any] | None = None
    old_no = new_no = 0
    in_hunk = False

    for raw in text.splitlines():
        line = raw.rstrip("\r")

        if line.startswith("diff --git "):
            cur = _new_file()
            files.append(cur)
            hunk = None
            in_hunk = False
            rest = line[len("diff --git "):]
            m = re.match(r'^("?a/[^"]*"?)\s+("?b/.*"?)$', rest)
            if m:
                cur["old_path"] = _strip_prefix(_clean_path(m.group(1)))
                cur["path"] = _strip_prefix(_clean_path(m.group(2)))
            continue

        if cur is None:
            continue

        if not in_hunk and line.startswith("--- "):
            cur["old_path"] = _strip_prefix(_clean_path(line[4:]))
            continue
        if not in_hunk and line.startswith("+++ "):
            cur["path"] = _strip_prefix(_clean_path(line[4:]))
            continue
        if line.startswith("new file mode"):
            cur["is_new"] = True
            continue
        if line.startswith("deleted file mode"):
            cur["is_deleted"] = True
            continue
        if line.startswith("rename from "):
            cur["old_path"] = _clean_path(line[len("rename from "):])
            continue
        if line.startswith("rename to "):
            cur["path"] = _clean_path(line[len("rename to "):])
            continue
        if line.startswith("Binary files ") or line.startswith("GIT binary patch"):
            cur["binary"] = True
            continue

        if line.startswith("@@"):
            m = re.match(r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@ ?(.*)$", line)
            if not m:
                continue
            old_no = int(m.group(1))
            new_no = int(m.group(3))
            hunk = {
                "header": line,
                "old_start": old_no,
                "new_start": new_no,
                "context": m.group(5),
                "lines": [],
            }
            cur["hunks"].append(hunk)
            in_hunk = True
            continue

        if not in_hunk or hunk is None:
            continue
        if line.startswith("\\"):
            continue

        if line.startswith("+"):
            hunk["lines"].append({"type": "+", "new_line": new_no, "old_line": None, "text": line[1:]})
            cur["added"] += 1
            new_no += 1
        elif line.startswith("-"):
            hunk["lines"].append({"type": "-", "new_line": None, "old_line": old_no, "text": line[1:]})
            cur["deleted"] += 1
            old_no += 1
        elif line.startswith(" "):
            hunk["lines"].append({"type": " ", "new_line": new_no, "old_line": old_no, "text": line[1:]})
            old_no += 1
            new_no += 1
        elif line == "":
            # Some editors strip the single leading space of a blank context line.
            hunk["lines"].append({"type": " ", "new_line": new_no, "old_line": old_no, "text": ""})
            old_no += 1
            new_no += 1

    for f in files:
        if not f["path"]:
            f["path"] = f["old_path"]
        f["language"] = EXT_LANG.get(Path(f["path"] or "").suffix.lower(), "text")

    total_added = sum(f["added"] for f in files)
    total_deleted = sum(f["deleted"] for f in files)
    return {
        "stats": {
            "files": len(files),
            "added": total_added,
            "deleted": total_deleted,
            "binary": sum(1 for f in files if f["binary"]),
        },
        "files": files,
    }


def iter_added(doc: dict[str, Any]) -> Iterable[tuple[dict[str, Any], dict[str, Any]]]:
    for f in doc["files"]:
        if f["binary"] or f["is_deleted"]:
            continue
        for h in f["hunks"]:
            for ln in h["lines"]:
                if ln["type"] == "+":
                    yield f, ln


# --------------------------------------------------------------------------
# rules
# --------------------------------------------------------------------------

SECRET_RULES: list[dict[str, Any]] = [
    {
        "id": "secret.private_key",
        "severity": "P0",
        "category": "security",
        "pattern": re.compile(r"-----BEGIN (?:[A-Z0-9 ]+ )?PRIVATE KEY-----"),
        "message": "私钥内容出现在变更中",
        "mask": "private_key",
    },
    {
        "id": "secret.aws_access_key",
        "severity": "P0",
        "category": "security",
        "pattern": re.compile(r"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b"),
        "message": "疑似 AWS Access Key 硬编码",
        "mask": "token",
    },
    {
        "id": "secret.github_token",
        "severity": "P0",
        "category": "security",
        "pattern": re.compile(r"\b(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{20,}\b|\bgithub_pat_[A-Za-z0-9_]{20,}\b"),
        "message": "疑似 GitHub Token 硬编码",
        "mask": "token",
    },
    {
        "id": "secret.slack_token",
        "severity": "P0",
        "category": "security",
        "pattern": re.compile(r"\bxox[baprs]-[A-Za-z0-9-]{10,}\b"),
        "message": "疑似 Slack Token 硬编码",
        "mask": "token",
    },
    {
        "id": "secret.jwt",
        "severity": "P1",
        "category": "security",
        "pattern": re.compile(r"\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b"),
        "message": "疑似 JWT 硬编码",
        "mask": "token",
    },
    {
        "id": "secret.assignment",
        "severity": "P1",
        "category": "security",
        "pattern": re.compile(
            r"(?i)(password|passwd|pwd|secret|api[_-]?key|access[_-]?token|auth[_-]?token)"
            r"\s*[:=]\s*(['\"])([^'\"]{8,})\2"
        ),
        "message": "疑似硬编码口令/密钥",
        "mask": "assignment",
    },
]

DANGER_RULES: list[dict[str, Any]] = [
    {"id": "py.eval", "severity": "P1", "category": "security",
     "pattern": re.compile(r"\beval\s*\("), "message": "eval() 执行动态代码，存在注入风险", "exts": {".py"}},
    {"id": "py.exec", "severity": "P1", "category": "security",
     "pattern": re.compile(r"\bexec\s*\("), "message": "exec() 执行动态代码，存在注入风险", "exts": {".py"}},
    {"id": "py.os_system", "severity": "P1", "category": "security",
     "pattern": re.compile(r"\bos\.system\s*\("), "message": "os.system 调用外部命令，存在命令注入风险", "exts": {".py"}},
    {"id": "py.subprocess_shell", "severity": "P1", "category": "security",
     "pattern": re.compile(r"subprocess\.(?:run|call|Popen|check_output|check_call)\([^)]*shell\s*=\s*True"),
     "message": "subprocess 使用 shell=True", "exts": {".py"}},
    {"id": "py.pickle", "severity": "P1", "category": "security",
     "pattern": re.compile(r"\bpickle\.loads?\s*\("), "message": "pickle 反序列化不可信数据", "exts": {".py"}},
    {"id": "py.yaml_load", "severity": "P2", "category": "security",
     "pattern": re.compile(r"\byaml\.load\s*\((?![^)]*Loader)"), "message": "yaml.load 未指定 SafeLoader", "exts": {".py"}},
    {"id": "py.verify_false", "severity": "P1", "category": "security",
     "pattern": re.compile(r"\bverify\s*=\s*False\b"), "message": "关闭了 TLS 证书校验", "exts": {".py"}},
    {"id": "py.ssl_unverified", "severity": "P1", "category": "security",
     "pattern": re.compile(r"_create_unverified_context|CERT_NONE"), "message": "跳过 TLS 证书校验", "exts": {".py"}},
    {"id": "py.debug_true", "severity": "P2", "category": "security",
     "pattern": re.compile(r"(?i)^\s*DEBUG\s*=\s*True\b"), "message": "DEBUG=True 可能泄露堆栈信息", "exts": {".py"}},
    {"id": "py.weak_hash", "severity": "P2", "category": "security",
     "pattern": re.compile(r"(?i)\b(?:md5|sha1)\s*\([^)]*(?:password|passwd|pwd)"), "message": "使用 MD5/SHA1 处理口令", "exts": {".py"}},
    {"id": "py.sql_format", "severity": "P1", "category": "security",
     "pattern": re.compile(r"\.execute\s*\(\s*(?:f[\"']|[\"'][^\"']*[\"']\s*(?:%|\+|\.format\())"),
     "message": "SQL 由字符串拼接构造，存在注入风险", "exts": {".py"}},
    {"id": "py.sql_concat", "severity": "P1", "category": "security",
     "pattern": re.compile(r"(?i)^\s*(?:sql|query)\s*=\s*.*\+"), "message": "SQL 语句由字符串拼接构造", "exts": {".py"}},
    {"id": "py.sql_fstring", "severity": "P1", "category": "security",
     "pattern": re.compile(r"(?i)^\s*(?:sql|query)\s*=\s*f[\"']\s*(?:select|delete|update|insert)\b"),
     "message": "SQL 语句由 f-string 构造", "exts": {".py"}},
    {"id": "py.mutable_default", "severity": "P2", "category": "correctness",
     "pattern": re.compile(r"^\s*def\s+\w+\([^)]*=\s*(?:\[\]|\{\})\s*[,)]"),
     "message": "可变对象作为默认参数，会在调用间共享", "exts": {".py"}},
    {"id": "web.inner_html", "severity": "P2", "category": "security",
     "pattern": re.compile(r"\.innerHTML\s*=|dangerouslySetInnerHTML"), "message": "直接写入 HTML，存在 XSS 风险",
     "exts": {".js", ".jsx", ".ts", ".tsx"}},
    {"id": "web.cors_all", "severity": "P2", "category": "security",
     "pattern": re.compile(r"(?i)allow_origins\s*=\s*\[\s*[\"']\*[\"']\s*\]"), "message": "CORS 允许任意来源", "exts": {".py"}},
]

DEBRIS_RULES: list[dict[str, Any]] = [
    {"id": "debug.print", "severity": "P3", "category": "style",
     "pattern": re.compile(r"^\s*print\s*\("), "message": "调试用 print 残留", "exts": {".py"}},
    {"id": "debug.console", "severity": "P2", "category": "style",
     "pattern": re.compile(r"\bconsole\.(?:log|debug)\s*\("), "message": "调试用 console 残留",
     "exts": {".js", ".jsx", ".ts", ".tsx"}},
    {"id": "debug.breakpoint", "severity": "P2", "category": "correctness",
     "pattern": re.compile(r"\b(?:breakpoint\(\)|pdb\.set_trace\(\))"), "message": "调试断点残留", "exts": {".py"}},
    {"id": "todo.marker", "severity": "P3", "category": "maintainability",
     "pattern": re.compile(r"\b(?:TODO|FIXME|HACK|XXX)\b"), "message": "遗留 TODO/FIXME", "exts": None},
    {"id": "code.commented", "severity": "P3", "category": "style",
     "pattern": re.compile(r"^\s*#\s*(?:def |class |import |from |return |if |for |while |[A-Za-z_]\w*\s*=)"),
     "message": "疑似注释掉的代码", "exts": {".py"}},
    {"id": "py.bare_except", "severity": "P2", "category": "correctness",
     "pattern": re.compile(r"^\s*except\s*:"), "message": "裸 except 会吞掉所有异常", "exts": {".py"}},
    {"id": "py.except_pass", "severity": "P2", "category": "correctness",
     "pattern": re.compile(r"^\s*except\s+[^:]+:\s*(?:pass|\.\.\.)\s*$"), "message": "异常被静默吞掉", "exts": {".py"}},
]


def mask_secret(value: str) -> str:
    v = value.strip()
    if len(v) <= 8:
        return "*" * len(v)
    return v[:4] + "*" * max(4, len(v) - 6) + v[-2:]


def _evidence(rule: dict[str, Any], match: re.Match[str], text: str) -> str:
    mode = rule.get("mask")
    if mode == "private_key":
        return "-----BEGIN PRIVATE KEY-----<masked>"
    if mode == "assignment":
        key, value = match.group(1), match.group(3)
        return f"{key} = {mask_secret(value)}"
    if mode == "token":
        return mask_secret(match.group(0))
    ev = text.strip()
    return ev[:200] + ("..." if len(ev) > 200 else "")


def scan_diff(doc: dict[str, Any]) -> dict[str, Any]:
    findings: list[dict[str, Any]] = []
    seen: set[tuple[str, str, int]] = set()

    for f, ln in iter_added(doc):
        ext = Path(f["path"] or "").suffix.lower()
        text = ln["text"]
        is_comment = text.lstrip().startswith(("#", "//"))
        rules = SECRET_RULES + ([] if is_comment else DANGER_RULES) + DEBRIS_RULES
        for rule in rules:
            exts = rule.get("exts")
            if exts and ext not in exts:
                continue
            m = rule["pattern"].search(text)
            if not m:
                continue
            key = (rule["id"], f["path"], ln["new_line"])
            if key in seen:
                continue
            seen.add(key)
            findings.append({
                "rule": rule["id"],
                "severity": rule["severity"],
                "category": rule["category"],
                "file": f["path"],
                "line": ln["new_line"],
                "message": rule["message"],
                "evidence": _evidence(rule, m, text),
            })

    findings.sort(key=lambda x: (x["file"], x["line"], SEVERITY_ORDER.get(x["severity"], 9), x["rule"]))
    return {"stats": doc["stats"], "findings": findings, "signals": _signals(doc)}


def _is_test_path(path: str) -> bool:
    p = path.lower().replace("\\", "/")
    name = p.rsplit("/", 1)[-1]
    return (
        "/tests/" in p
        or "/test/" in p
        or name.startswith("test_")
        or name.endswith("_test.py")
        or name.endswith(".test.js")
        or name.endswith(".test.ts")
        or name.endswith(".spec.ts")
        or name.endswith(".spec.js")
    )


def _signals(doc: dict[str, Any]) -> dict[str, Any]:
    changed = [f for f in doc["files"] if not f["is_deleted"]]
    test_changed = any(_is_test_path(f["path"] or "") for f in changed)
    without_tests = []
    if not test_changed:
        without_tests = [
            f["path"] for f in changed
            if Path(f["path"] or "").suffix.lower() in SOURCE_EXTS and not _is_test_path(f["path"] or "")
        ]

    dependency_files = [f["path"] for f in changed if (f["path"] or "").rsplit("/", 1)[-1].lower() in DEPENDENCY_FILES]
    migration_files = [
        f["path"] for f in changed
        if re.search(r"(^|/)(migrations?|alembic|db/migrate)/", (f["path"] or "").lower())
        or (f["path"] or "").lower().endswith(".sql")
    ]
    sensitive_files = [
        f["path"] for f in changed
        if (f["path"] or "").rsplit("/", 1)[-1].lower() in SENSITIVE_NAMES
        or "/.github/workflows/" in (f["path"] or "").lower()
    ]
    large_files = [f["path"] for f in changed if f["added"] >= 300]
    binary_files = [f["path"] for f in doc["files"] if f["binary"]]

    return {
        "files_without_tests": without_tests,
        "dependency_files": dependency_files,
        "migration_files": migration_files,
        "sensitive_files": sensitive_files,
        "large_files": large_files,
        "binary_files": binary_files,
    }


# --------------------------------------------------------------------------
# verify
# --------------------------------------------------------------------------

def _norm_path(path: str) -> str:
    p = (path or "").strip().replace("\\", "/")
    while p.startswith("./"):
        p = p[2:]
    if p.startswith(("a/", "b/")):
        p = p[2:]
    return p


def right_side_positions(doc: dict[str, Any]) -> tuple[dict[str, set[int]], dict[str, set[int]]]:
    exact: dict[str, set[int]] = {}
    lowered: dict[str, set[int]] = {}
    for f in doc["files"]:
        if f["binary"]:
            continue
        lines: set[int] = set()
        for h in f["hunks"]:
            for ln in h["lines"]:
                if ln["type"] in ("+", " ") and ln["new_line"] is not None:
                    lines.add(ln["new_line"])
        p = _norm_path(f["path"] or "")
        exact.setdefault(p, set()).update(lines)
        lowered.setdefault(p.lower(), set()).update(lines)
    return exact, lowered


def verify_findings(doc: dict[str, Any], findings: list[dict[str, Any]]) -> dict[str, Any]:
    exact, lowered = right_side_positions(doc)
    valid: list[dict[str, Any]] = []
    invalid: list[dict[str, Any]] = []

    for item in findings:
        file = _norm_path(item.get("file", ""))
        line = item.get("line")
        positions = exact.get(file)
        if positions is None:
            positions = lowered.get(file.lower())
        if positions is None:
            invalid.append({"file": file, "line": line, "reason": "file not in diff"})
        elif not isinstance(line, int) or line not in positions:
            invalid.append({"file": file, "line": line, "reason": "line is not on the RIGHT side of the diff"})
        else:
            valid.append({"file": file, "line": line})

    return {"total": len(findings), "valid": valid, "invalid": invalid}


# --------------------------------------------------------------------------
# cli
# --------------------------------------------------------------------------

def _read_findings(path: str) -> list[dict[str, Any]]:
    data = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    if isinstance(data, dict):
        data = data.get("findings", [])
    if not isinstance(data, list):
        raise ValueError("findings JSON must be a list or an object with a 'findings' list")
    return data


def main(argv: list[str] | None = None) -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8")

    parser = argparse.ArgumentParser(description="Deterministic helpers for code review on unified diffs.")
    parser.add_argument("--mode", required=True, choices=["parse", "scan", "verify"])
    parser.add_argument("--diff", required=True, help="path to the unified diff file")
    parser.add_argument("--out", default=None, help="write JSON to this path instead of stdout")
    parser.add_argument("--findings", default=None, help="findings JSON (verify mode)")
    parser.add_argument("--pretty", action="store_true", help="indent the JSON output")
    args = parser.parse_args(argv)

    diff_path = Path(args.diff)
    if not diff_path.exists():
        print(f"diff file not found: {diff_path}", file=sys.stderr)
        return 2

    text = diff_path.read_text(encoding="utf-8", errors="replace")
    doc = parse_diff(text)

    if args.mode == "parse":
        result: Any = doc
    elif args.mode == "scan":
        result = scan_diff(doc)
    else:
        if not args.findings:
            print("--findings is required in verify mode", file=sys.stderr)
            return 2
        result = verify_findings(doc, _read_findings(args.findings))

    payload = json.dumps(result, ensure_ascii=False, indent=2 if args.pretty else None)
    if args.out:
        out_path = Path(args.out)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(payload, encoding="utf-8")
        print(f"written: {out_path}", file=sys.stderr)
    else:
        print(payload)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
