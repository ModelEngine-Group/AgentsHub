# Python 审查清单（按需加载）

> 只列「模型容易漏、但确实会导致故障」的点。每条给出判定信号与修复方向，不展开教科书内容。

## 1. 可变默认参数

```python
def add(item, bucket=[]):      # 错：所有调用共享同一个 list
    bucket.append(item)
```

判定：`def f(..., x=[]/{}/set())`。
修复：默认值用 `None`，函数体内 `x = x or []`（注意 `0`/`""` 的语义）或 `x if x is not None else []`。

## 2. 裸 except / 静默吞异常

```python
try:
    ...
except:                        # 错：KeyboardInterrupt、SystemExit 也会被吞
    pass
```

判定：`except:`、`except Exception: pass`、空 `catch`。
修复：捕获具体异常；至少记录日志并保留堆栈。

## 3. 资源未释放

判定：`open()`、`requests`、数据库连接、锁没有 `with` / `finally`。
修复：`with open(...) as f:`；连接池用上下文管理器。

## 4. 事务边界

判定：一次业务写多张表，但只有单条 `execute` 或没有 `commit/rollback`；异常路径不回滚。
修复：显式事务，异常回滚，必要时用 `session.begin()`。

## 5. 空值与类型边界

判定：外部输入（HTTP、消息、文件）直接参与运算/索引/`split`；`None` 未判空；`int()`/`float()` 未捕获 `ValueError`。
修复：入口校验 + 明确默认值；用 `pydantic`/`dataclass` 收敛类型。

## 6. 权限校验缺失（IDOR）

判定：接口只校验「已登录」，不校验资源归属；`get(id=...)` 直接返回。
修复：查询条件带上 `owner_id`/`tenant_id`，或查询后显式鉴权。

## 7. SQL / 命令 / 路径注入

判定：f-string、`%`、`+`、`.format()` 拼接 SQL；`os.system`、`shell=True`；`open(os.path.join(base, user_input))` 未规范化。
修复：参数化查询；`subprocess.run([...], shell=False)`；`Path.resolve()` 后校验前缀。

## 8. 不安全的反序列化

判定：`pickle.loads`、`yaml.load`（无 `SafeLoader`）、`marshal`、`eval` 处理外部数据。
修复：`json` / `yaml.safe_load`；必须 pickle 时加签名校验与来源白名单。

## 9. 认证与令牌

判定：JWT 未校验 `exp`/`aud`/签名算法；`alg=none` 可用；Token 写日志；随机数用 `random` 生成令牌。
修复：固定算法白名单，校验过期与受众；令牌用 `secrets.token_urlsafe()`。

## 10. 口令与加密

判定：MD5/SHA1 存口令；明文比较；硬编码盐；`==` 比较 HMAC。
修复：`bcrypt`/`argon2`；`hmac.compare_digest`。

## 11. 并发与共享状态

判定：模块级 dict/list 做缓存无锁；`check-then-act`；线程池里改共享对象；异步函数里调用阻塞 IO。
修复：`Lock`/`RLock`，或用事务/原子操作；异步链路统一 `async` 客户端。

## 12. 时间与金额

判定：`datetime.now()` 无时区；naive/aware 混用；`float` 表示金额；`round()` 做金额舍入。
修复：`datetime.now(timezone.utc)`；`Decimal` + 明确舍入模式。

## 13. 迭代与闭包

判定：遍历 list 时删除元素；闭包延迟绑定循环变量；`is` 比较字符串/整数。
修复：列表推导或倒序删除；`functools.partial` / 默认参数绑定；`==` 比较值。

## 14. 日志与可观测性

判定：异常只 `print`；日志拼接用户输入；日志里出现手机号、身份证、Token；关键分支无日志。
修复：`logger.exception`；结构化日志；敏感字段脱敏。

## 15. 外部调用健壮性

判定：`requests` 无 `timeout`；无重试/退避；不处理非 2xx；把第三方返回值直接透传。
修复：连接/读取超时、有限重试、熔断；校验响应结构。

## 16. 配置与密钥

判定：密钥硬编码；`DEBUG=True` 进生产；CORS `*`；默认口令。
修复：环境变量/密钥管理；启动时校验必填配置，缺失即失败。

## 17. 测试覆盖

判定：新增分支/异常路径无对应用例；只测 happy path；测试依赖真实外部服务。
修复：为本次变更的关键分支补最小用例；外部依赖用 fake/mock。

## 18. 兼容性与迁移

判定：修改公共函数签名/返回结构；数据库加非空列无默认值；删除字段；修改枚举值。
修复：向后兼容的过渡期；迁移脚本可回滚；调用方同步修改。

## 19. 依赖变更

判定：新增依赖未锁定版本；来源不明；许可证不兼容；升级大版本无迁移说明。
修复：锁定版本与哈希；审查许可证；在 PR 描述里说明升级影响。

## 20. 性能热点

判定：循环内查库/发 HTTP（N+1）；一次性加载大表；正则 catastrophic backtracking；大文件全量读入内存。
修复：批量查询、分页、流式处理、预编译正则。

---

## 使用方式

1. 先看 `scan` 的候选，再按本清单补语义问题。
2. 只引用与本次 diff 有关的条目，不要整份清单复述给用户。
3. 每条意见必须能落到「文件:行 + 失败场景 + 修复方向」。
