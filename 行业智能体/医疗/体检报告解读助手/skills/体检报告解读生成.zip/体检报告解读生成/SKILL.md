---
name: 体检报告解读生成
description: 根据处理后的体检数据，生成规范的体检报告解读。适用于处理后的数据，生成结构化、格式化的报告。
tags:
- 体检报告
- 数据解读
- 健康报告
---

# 📋 您的专属体检报告解读

> 报告生成时间：{{current_time}} | 基于联网最新指南

---

## 📸 原始报告信息
- **报告类型**：{{report_type}}（血常规/CT影像/生化全套等）
- **识别方式**：OCR智能识别
- **识别时间**：{{ocr_time}}
- **主要异常指标**：{{abnormal_summary}}

---

## 📊 第一部分：全局健康画像

### 1.1 核心健康短板雷达图
> 以下雷达图展示您各系统的健康水平（分值越高越健康）

{{radar_chart_placeholder}}
*图：您的健康多维评估（满分10分）*

**解读**：您的健康短板主要集中在 **{{weakness_area}}** 方面，其次是 **{{secondary_weakness}}**。

### 1.2 指标异常分布
{{pie_chart_placeholder}}
*图：正常 vs 异常指标占比*

| 状态 | 数量 | 占比 |
|------|------|------|
| 正常 | {{normal_count}} | {{normal_percent}}% |
| 偏高 | {{high_count}} | {{high_percent}}% |
| 偏低 | {{low_count}} | {{low_percent}}% |

---

## 🔍 第二部分：异常指标详解

### 2.1 超标/不足指标排行
{{column_chart_placeholder}}
*图：偏离正常范围最大的前5项指标*

| 排名 | 指标名称 | 您的值 | 参考范围 | 偏离程度 |
|------|---------|--------|---------|----------|
| 1 | {{item1}} | {{value1}} | {{ref1}} | {{deviation1}} |
| 2 | {{item2}} | {{value2}} | {{ref2}} | {{deviation2}} |
| 3 | {{item3}} | {{value3}} | {{ref3}} | {{deviation3}} |

### 2.2 各异常指标详细解读

{{#each abnormal_items}}
#### 🩸 {{this.name}} —— {{this.value}} {{this.unit}}（参考：{{this.ref}}）

**状态**：{{this.status}} {{this.emoji}}

**结果解读**：
{{this.interpretation}}（来源：{{this.knowledge_source}}）

**与同龄人比较**：
{{boxplot_chart_placeholder}}
*图：您在{{this.name}}指标上的同龄人百分位*

{{#if (gt this.percentile 90)}}
⚠️ 您处于同龄人群的前10%，需要重点关注。
{{else if (lt this.percentile 10)}}
✅ 您处于同龄人群的后10%，表现优秀。
{{else}}
您处于同龄人的中等水平。
{{/if}}

**可能的病因分析**（鱼骨图）：
{{fishbone_diagram_placeholder}}
*图：{{this.name}}异常的可能原因分析*

{{/each}}

---

## 💡 第三部分：核心指标聚焦

### 最关键指标：{{critical_indicator.name}}

{{liquid_chart_placeholder}}
*图：{{critical_indicator.name}}当前值 vs 理想目标*

| 维度 | 数据 |
|------|------|
| 当前值 | {{critical_indicator.value}} {{critical_indicator.unit}} |
| 理想目标 | {{critical_indicator.target}} {{critical_indicator.unit}} |
| 达成进度 | {{critical_indicator.progress}}% |

---

## 🥗 第四部分：AI健康指导（基于联网最新指南）

### 4.1 饮食调整建议

> 以下建议基于联网检索：{{diet_search_keyword}}

{{#each diet_advice}}
- **{{this.food_category}}**：{{this.suggestion}}
  - 推荐：{{this.recommended}}
  - 限制：{{this.limited}}
{{/each}}

### 4.2 运动处方

> 以下建议基于联网检索：{{exercise_search_keyword}}

- **运动类型**：{{exercise_type}}
- **推荐频率**：{{exercise_frequency}}
- **单次时长**：{{exercise_duration}}
- **强度控制**：{{exercise_intensity}}
- **注意事项**：{{exercise_precaution}}

### 4.3 生活方式调整

{{#each lifestyle_advice}}
- {{this}}
{{/each}}

---

## 📅 第五部分：行动计划

### 短期（1周内）
{{short_term_actions}}

### 中期（1-3个月）
{{mid_term_actions}}

### 复查建议
- **{{critical_indicator.name}}**：建议 {{followup_interval_critical}} 复查
- **其他异常指标**：建议 {{followup_interval_other}} 复查

---

## ⚠️ 免责声明

> 本报告由AI健康助手生成，解读基于联网公开指南和医学知识库，**不能替代执业医师的面对面诊疗**。如有身体不适，请及时就医。生成图表基于您提供的数据估算，仅供参考。

---

*报告结束 —— 祝您身体健康！*